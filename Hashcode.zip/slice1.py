def getValues(filename):
    with open(filename) as f:
        m, n = map(int, f.readline().split())
        pizzas = list(map(int, f.readline().split()))
        f.close()

    return m, n, pizzas


def getInd2Rem(pizzas, diff, indices):
    vals = [pizzas[x] for x in indices]
    best = vals[0]
    for i in vals:
        if i > diff:
            excess = i - diff
            rem = diff - best
            if min(vals) > (excess + rem):
                return indices[vals.index(i)]
            break
        best = i
    return indices[vals.index(best)]

def getSlices(pizzas, maxi):
    _sum = 0
    current = 0
    indices = []
    while _sum <= maxi:
        _sum += pizzas[current]
        indices.append(current)
        current += 1

    diff = _sum - maxi
    while _sum > maxi:
        ind2rem = getInd2Rem(pizzas, diff, indices)
        _sum -= pizzas[ind2rem]
        indices.remove(ind2rem)
        diff = _sum - maxi
    
    print(_sum)
    return indices


if __name__ == "__main__":
    files = ['c_medium.in', 'd_quite_big.in', 'e_also_big.in']
    for filename in files:
        m, n, pizzas = getValues('data/' + filename)
        print(filename, m, sep='\n')
        slices = getSlices(pizzas, m)
        with open('output/output_' + filename, 'w') as f:
            f.write(str(len(slices)) + '\n')
            f.write(' '.join(map(str, slices)))
            f.close()


    

